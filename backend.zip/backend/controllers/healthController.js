const { poolPromise } = require('../config/db');

// Sağlık verisi ekleme
exports.addHealthData = async (req, res) => {
  const { suTuketimi, adimSayisi, uykuSuresi, kalpAtisi } = req.body;
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    await pool.request()
      .input('KullaniciID', userId)
      .input('SuTuketimi', suTuketimi)
      .input('AdimSayisi', adimSayisi)
      .input('UykuSuresi', uykuSuresi)
      .input('KalpAtisi', kalpAtisi)
      .query(`
        INSERT INTO SaglikVerileri 
        (KullaniciID, SuTuketimi, AdimSayisi, UykuSuresi, KalpAtisi, Tarih)
        VALUES 
        (@KullaniciID, @SuTuketimi, @AdimSayisi, @UykuSuresi, @KalpAtisi, SYSDATETIME())
      `);

    return res.status(201).json({ mesaj: 'Veri eklendi' });
  } catch (err) {
    console.error(err);
    return res.status(500).send('Veri eklenirken hata oluştu');
  }
};

// Tüm verileri çekme
exports.getAllHealthData = async (req, res) => {
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', userId)
      .query(`
        SELECT * FROM SaglikVerileri 
        WHERE KullaniciID = @KullaniciID 
        ORDER BY Tarih DESC
      `);

    return res.json(result.recordset);
  } catch (err) {
    console.error(err);
    return res.status(500).send('Veriler alınırken hata oluştu');
  }
};

// Veriyi güncelleme
exports.updateHealthData = async (req, res) => {
  const { veriID } = req.params;
  const { suTuketimi, adimSayisi, uykuSuresi, kalpAtisi } = req.body;
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('VeriID', veriID)
      .input('KullaniciID', userId)
      .input('SuTuketimi', suTuketimi)
      .input('AdimSayisi', adimSayisi)
      .input('UykuSuresi', uykuSuresi)
      .input('KalpAtisi', kalpAtisi)
      .query(`
        UPDATE SaglikVerileri
        SET SuTuketimi = @SuTuketimi,
            AdimSayisi = @AdimSayisi,
            UykuSuresi = @UykuSuresi,
            KalpAtisi = @KalpAtisi
        WHERE VeriID = @VeriID AND KullaniciID = @KullaniciID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).send('Veri bulunamadı veya yetkisiz');
    }

    return res.send('Veri güncellendi');
  } catch (err) {
    console.error(err);
    return res.status(500).send('Güncelleme sırasında hata oluştu');
  }
};

// Veriyi silme
exports.deleteHealthData = async (req, res) => {
  const { veriID } = req.params;
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('VeriID', veriID)
      .input('KullaniciID', userId)
      .query(`
        DELETE FROM SaglikVerileri 
        WHERE VeriID = @VeriID AND KullaniciID = @KullaniciID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).send('Veri bulunamadı veya yetkisiz');
    }

    return res.send('Veri silindi');
  } catch (err) {
    console.error(err);
    return res.status(500).send('Silme sırasında hata oluştu');
  }
};

// Tarih filtreli verileri çekme
exports.getHealthDataByDate = async (req, res) => {
  const userId = req.userId;
  const { baslangic, bitis } = req.query;

  if (!baslangic || !bitis) {
    return res.status(400).send("Başlangıç ve bitiş tarihi zorunludur.");
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', userId)
      .input('Baslangic', baslangic)
      .input('Bitis', bitis)
      .query(`
        SELECT * FROM SaglikVerileri 
        WHERE KullaniciID = @KullaniciID 
          AND CONVERT(DATE, Tarih) BETWEEN @Baslangic AND @Bitis
        ORDER BY Tarih DESC
      `);

    return res.json(result.recordset);
  } catch (err) {
    console.error('❌ getHealthDataByDate Hatası:', err);
    return res.status(500).send("Tarih aralığına göre veri alınamadı.");
  }
};

// ✅ En son girilen sağlık verisini getir
exports.getLastHealthData = async (req, res) => {
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', userId)
      .query(`
        SELECT TOP 1 UykuSuresi, KalpAtisi, AdimSayisi, SuTuketimi
        FROM SaglikVerileri
        WHERE KullaniciID = @KullaniciID
        ORDER BY Tarih DESC
      `);

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: 'Veri bulunamadı' });
    }

    const veri = result.recordset[0];
    res.json({
      uykuSuresi: veri.UykuSuresi,
      kalpAtisHizi: veri.KalpAtisi,
      adimSayisi: veri.AdimSayisi,
      suTuketimi: veri.SuTuketimi
    });
  } catch (err) {
    console.error('Son veri hatası:', err);
    return res.status(500).send('Son veri alınamadı');
  }
};
// Hedef özet verilerini getir (adım, su, uyku - 30 gün)
exports.getHedefOzet = async (req, res) => {
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', userId)
      .query(`
        SELECT 
          SUM(AdimSayisi) AS ToplamAdim,
          SUM(SuTuketimi) AS ToplamSu,
          SUM(UykuSuresi) AS ToplamUyku,
          COUNT(*) AS GunSayisi
        FROM SaglikVerileri
        WHERE KullaniciID = @KullaniciID
          AND Tarih >= DATEADD(DAY, -30, GETDATE())
      `);

    const {
      ToplamAdim = 0,
      ToplamSu = 0,
      ToplamUyku = 0,
      GunSayisi = 1
    } = result.recordset[0];

    return res.json({
      adim: {
        toplam: ToplamAdim,
        ortalama: Math.round(ToplamAdim / GunSayisi)
      },
      su: {
        toplam: parseFloat(ToplamSu.toFixed(2)),
        ortalama: parseFloat((ToplamSu / GunSayisi).toFixed(2))
      },
      uyku: {
        toplam: parseFloat(ToplamUyku.toFixed(2)),
        ortalama: parseFloat((ToplamUyku / GunSayisi).toFixed(2))
      }
    });
  } catch (err) {
    console.error('⚠️ Hedef özet hatası:', err);
    return res.status(500).send('Hedef özeti alınamadı');
  }
};
// ✅ Sadece bugünkü sağlık verilerini getir (günlük hedef karşılaştırması için)
exports.getTodayHealthData = async (req, res) => {
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', userId)
      .query(`
        SELECT TOP 1 SuTuketimi, AdimSayisi, UykuSuresi
        FROM SaglikVerileri
        WHERE KullaniciID = @KullaniciID
          AND CAST(Tarih AS DATE) = CAST(GETDATE() AS DATE)
        ORDER BY Tarih DESC
      `);

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: 'Bugün için veri bulunamadı' });
    }

    const veri = result.recordset[0];
    res.json({
      adim: veri.AdimSayisi,
      su: veri.SuTuketimi,
      uyku: veri.UykuSuresi
    });
  } catch (err) {
    console.error('❌ Bugünkü sağlık verisi hatası:', err);
    return res.status(500).send('Bugünkü sağlık verisi alınamadı');
  }
};


exports.getWeeklyHealthData = async (req, res) => {
  const userId = req.userId;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', userId)
      .query(`
        SELECT 
          FORMAT(Tarih, 'dd.MM') AS Tarih,
          UykuSuresi,
          KalpAtisi,
          AdimSayisi,
          SuTuketimi
        FROM (
          SELECT *, ROW_NUMBER() OVER (PARTITION BY CONVERT(DATE, Tarih) ORDER BY Tarih DESC) AS rn
          FROM SaglikVerileri
          WHERE KullaniciID = @KullaniciID
            AND CONVERT(DATE, Tarih) >= CONVERT(DATE, DATEADD(DAY, -6, GETDATE()))
        ) AS alt
        WHERE rn = 1
        ORDER BY CONVERT(DATE, Tarih)
      `);

    return res.json(result.recordset);
  } catch (err) {
    console.error('❌ Haftalık veri hatası:', err);
    return res.status(500).send('Haftalık sağlık verisi alınamadı');
  }
};
