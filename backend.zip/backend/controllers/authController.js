const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { poolPromise } = require('../config/db');
require('dotenv').config();

const SECRET_KEY = process.env.JWT_SECRET;

// ✅ Kayıt İşlemi
exports.register = async (req, res) => {
  const { ad, soyad, email, sifre } = req.body;

  if (!ad || !soyad || !email || !sifre) {
    return res.status(400).json({ message: 'Tüm alanlar zorunludur' });
  }

  try {
    const sifreHash = await bcrypt.hash(sifre, 10);
    const pool = await poolPromise;

    await pool.request()
      .input('Ad', ad.trim())
      .input('Soyad', soyad.trim())
      .input('Email', email.trim().toLowerCase())
      .input('SifreHash', sifreHash)
      .query(`
        INSERT INTO Kullanicilar (Ad, Soyad, Email, SifreHash)
        VALUES (@Ad, @Soyad, @Email, @SifreHash)
      `);

    res.status(201).json({ message: 'Kayıt başarılı' });
  } catch (err) {
    if (err.originalError?.info?.number === 2627) {
      return res.status(400).json({ message: 'Bu e-posta adresi zaten kayıtlı' });
    }
    console.error('Kayıt hatası:', err);
    res.status(500).json({ message: 'Kayıt sırasında hata oluştu' });
  }
};

// ✅ Giriş İşlemi
exports.login = async (req, res) => {
  const { email, sifre } = req.body;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('Email', email.trim().toLowerCase())
      .query('SELECT * FROM Kullanicilar WHERE Email = @Email');

    const user = result.recordset[0];
    if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });

    const isMatch = await bcrypt.compare(sifre, user.SifreHash);
    if (!isMatch) return res.status(401).json({ message: 'Şifre yanlış' });

    const token = jwt.sign({ userId: user.KullaniciID }, SECRET_KEY, { expiresIn: '1h' });

    res.json({
      token,
      user: {
        ad: user.Ad || '',
        soyad: user.Soyad || ''
      }
    });
  } catch (err) {
    console.error('Login hatası:', err);
    res.status(500).json({ message: 'Giriş sırasında sunucu hatası oluştu' });
  }
};
