const request = require('supertest');
const chai = require('chai');
const expect = chai.expect;
const app = require('../app');

let token;
let createdVeriID;

describe('💓 Sağlık Verileri API Testleri', () => {
  before(async () => {
    // Giriş yap ve token al
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        sifre: '123456'
      });

    expect(loginRes.status).to.equal(200);
    token = loginRes.body.token;
  });

  it('1️⃣ Sağlık verisi eklenmeli', async () => {
    const res = await request(app)
      .post('/api/health/add')
      .set('Authorization', `Bearer ${token}`)
      .send({
        suTuketimi: 1.5,
        adimSayisi: 4000,
        uykuSuresi: 6,
        kalpAtisi: 72
      });

    expect(res.status).to.equal(201);
  });

  it('2️⃣ Sağlık verileri listelenmeli', async () => {
    const res = await request(app)
      .get('/api/health/all')
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).to.equal(200);
    expect(res.body).to.be.an('array');
    expect(res.body.length).to.be.greaterThan(0);

    createdVeriID = res.body[0].VeriID; // Sonradan güncelleme/silme için
  });

  it('3️⃣ Sağlık verisi güncellenmeli', async () => {
    const res = await request(app)
      .put(`/api/health/update/${createdVeriID}`)
      .set('Authorization', `Bearer ${token}`)
      .send({
        suTuketimi: 2.0,
        adimSayisi: 5000,
        uykuSuresi: 7,
        kalpAtisi: 75
      });

    expect(res.status).to.equal(200);
  });

  it('4️⃣ Sağlık verisi silinmeli', async () => {
    const res = await request(app)
      .delete(`/api/health/delete/${createdVeriID}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).to.equal(200);
  });
});
