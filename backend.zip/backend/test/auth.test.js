const request = require('supertest');
const chai = require('chai');
const expect = chai.expect;
const app = require('../app'); // app.js içindeki express() nesnesi

describe('🔐 Auth API Testleri', () => {
  const testEmail = 'test@example.com';
  const testPassword = '123456';

  it('1️⃣ Kayıt: Yeni kullanıcı oluşturulmalı (veya daha önce varsa 400 dönmeli)', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        adSoyad: 'Test Kullanıcı',
        email: testEmail,
        sifre: testPassword
      });

    expect([201, 400]).to.include(res.status);
  });

  it('2️⃣ Giriş: Doğru bilgilerle giriş yapılabilmeli', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: testEmail,
        sifre: testPassword
      });

    expect(res.status).to.equal(200);
    expect(res.body).to.have.property('token');
  });
});
