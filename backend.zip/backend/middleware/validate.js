module.exports = {
  validateRegister: (req, res, next) => {
    const { ad, soyad, email, sifre } = req.body;
    if (!ad || !soyad || !email || !sifre) {
      return res.status(400).send('Ad, Soyad, Email ve Şifre zorunludur');
    }
    next();
  },

  validateLogin: (req, res, next) => {
    const { email, sifre } = req.body;
    if (!email || !sifre) {
      return res.status(400).send('Email ve Şifre zorunludur');
    }
    next();
  },

  validateHealthData: (req, res, next) => {
    const { suTuketimi, adimSayisi, uykuSuresi, kalpAtisi } = req.body;
    if (
      suTuketimi == null || adimSayisi == null ||
      uykuSuresi == null || kalpAtisi == null
    ) {
      return res.status(400).send('Tüm sağlık verileri zorunludur');
    }
    next();
  }
};
