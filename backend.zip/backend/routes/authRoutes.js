const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validateRegister, validateLogin } = require('../middleware/validate');

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     summary: Kullanıcı kaydı oluştur
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               adSoyad:
 *                 type: string
 *               email:
 *                 type: string
 *               sifre:
 *                 type: string
 *     responses:
 *       201:
 *         description: Kayıt başarılı
 *       400:
 *         description: Geçersiz giriş verileri veya e-posta zaten kayıtlı
 *       500:
 *         description: Sunucu hatası
 */
router.post('/register', validateRegister, authController.register);

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     summary: Kullanıcı girişi yap
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *               sifre:
 *                 type: string
 *     responses:
 *       200:
 *         description: Giriş başarılı ve token döndü
 *       400:
 *         description: Geçersiz giriş verileri
 *       401:
 *         description: Yanlış şifre
 *       404:
 *         description: Kullanıcı bulunamadı
 *       500:
 *         description: Sunucu hatası
 */
router.post('/login', validateLogin, authController.login);

module.exports = router;
