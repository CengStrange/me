const express = require('express');
const router = express.Router();
const { poolPromise } = require('../config/db');
const verifyToken = require('../middleware/authMiddleware');
const bcrypt = require('bcrypt');

// ✅ GET /api/kullanici/me → PROFİL BİLGİLERİ GETİR
router.get('/me', verifyToken, async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', req.userId)
      .query(`
        SELECT Ad, Soyad, Email, Yas, Boy, Kilo, Cinsiyet, DogumTarihi
        FROM Kullanicilar
        WHERE KullaniciID = @KullaniciID
      `);

    const user = result.recordset[0];
    if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });

    res.json({
      ad: user.Ad || '',
      soyad: user.Soyad || '',
      email: user.Email,
      yas: user.Yas || 0,
      boy: user.Boy || 0,
      kilo: user.Kilo || 0,
      cinsiyet: user.Cinsiyet || '',
      dogumTarihi: user.DogumTarihi || null
    });
  } catch (err) {
    console.error('/me hatası:', err);
    res.status(500).json({ message: 'Kullanıcı verisi alınamadı' });
  }
});

// ✅ PUT /api/kullanici/guncelle → PROFİL GÜNCELLE
router.put('/guncelle', verifyToken, async (req, res) => {
  const { ad, soyad, yas, boy, kilo, cinsiyet, dogumTarihi } = req.body;

  try {
    const pool = await poolPromise;
    await pool.request()
      .input('Ad', ad)
      .input('Soyad', soyad)
      .input('Yas', yas)
      .input('Boy', boy)
      .input('Kilo', kilo)
      .input('Cinsiyet', cinsiyet)
      .input('DogumTarihi', dogumTarihi)
      .input('KullaniciID', req.userId)
      .query(`
        UPDATE Kullanicilar
        SET Ad = @Ad, Soyad = @Soyad, Yas = @Yas, Boy = @Boy, Kilo = @Kilo,
            Cinsiyet = @Cinsiyet, DogumTarihi = @DogumTarihi
        WHERE KullaniciID = @KullaniciID
      `);

    res.status(200).json({ message: 'Profil güncellendi' });
  } catch (err) {
    console.error('❌ Güncelleme hatası:', err);
    res.status(500).json({ message: 'Güncelleme başarısız' });
  }
});

// ✅ PUT /api/kullanici/sifre-guncelle
router.put('/sifre-guncelle', verifyToken, async (req, res) => {
  const { eskiSifre, yeniSifre } = req.body;

  if (!eskiSifre || !yeniSifre) {
    return res.status(400).json({ message: 'Tüm alanlar zorunludur.' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('KullaniciID', req.userId)
      .query(`SELECT SifreHash FROM Kullanicilar WHERE KullaniciID = @KullaniciID`);

    const kullanici = result.recordset[0];
    if (!kullanici) return res.status(404).json({ message: 'Kullanıcı bulunamadı.' });

    const sifreDogruMu = await bcrypt.compare(eskiSifre, kullanici.SifreHash);
    if (!sifreDogruMu) return res.status(401).json({ message: 'Eski şifre hatalı.' });

    const yeniHash = await bcrypt.hash(yeniSifre, 10);

    await pool.request()
      .input('SifreHash', yeniHash)
      .input('KullaniciID', req.userId)
      .query(`UPDATE Kullanicilar SET SifreHash = @SifreHash WHERE KullaniciID = @KullaniciID`);

    res.status(200).json({ message: 'Şifre güncellendi.' });
  } catch (err) {
    console.error('Şifre güncelleme hatası:', err);
    res.status(500).json({ message: 'Sunucu hatası.' });
  }
});

module.exports = router;
