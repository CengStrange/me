const express = require('express');
const router = express.Router();
const healthController = require('../controllers/healthController');
const verifyToken = require('../middleware/authMiddleware');
const { validateHealthData } = require('../middleware/validate');

/**
 * @swagger
 * /api/health/add:
 *   post:
 *     summary: Sağlık verisi ekle
 *     tags: [Health]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               suTuketimi:
 *                 type: number
 *               adimSayisi:
 *                 type: number
 *               uykuSuresi:
 *                 type: number
 *               kalpAtisi:
 *                 type: number
 *     responses:
 *       201:
 *         description: Veri eklendi
 *       400:
 *         description: Eksik veri
 */
router.post('/add', verifyToken, validateHealthData, healthController.addHealthData);

/**
 * @swagger
 * /api/health/all:
 *   get:
 *     summary: Sağlık verilerini listele
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: Veriler başarılı bir şekilde alındı
 *       500:
 *         description: Sunucu hatası
 */
router.get('/all', verifyToken, healthController.getAllHealthData);

/**
 * @swagger
 * /api/health/by-date:
 *   get:
 *     summary: Sağlık verilerini tarih aralığına göre listele
 *     tags: [Health]
 *     parameters:
 *       - in: query
 *         name: baslangic
 *         required: true
 *         description: Başlangıç tarihi
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: bitis
 *         required: true
 *         description: Bitiş tarihi
 *         schema:
 *           type: string
 *           format: date
 *     responses:
 *       200:
 *         description: Veriler başarılı bir şekilde alındı
 *       400:
 *         description: Başlangıç ve bitiş tarihi gereklidir
 *       500:
 *         description: Sunucu hatası
 */
router.get('/by-date', verifyToken, healthController.getHealthDataByDate);

/**
 * @swagger
 * /api/health/update/{veriID}:
 *   put:
 *     summary: Sağlık verisini güncelle
 *     tags: [Health]
 *     parameters:
 *       - in: path
 *         name: veriID
 *         required: true
 *         description: Sağlık verisi ID'si
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               suTuketimi:
 *                 type: number
 *               adimSayisi:
 *                 type: number
 *               uykuSuresi:
 *                 type: number
 *               kalpAtisi:
 *                 type: number
 *     responses:
 *       200:
 *         description: Veri güncellendi
 *       400:
 *         description: Eksik veri
 *       404:
 *         description: Veri bulunamadı
 */
router.put('/update/:veriID', verifyToken, validateHealthData, healthController.updateHealthData);

/**
 * @swagger
 * /api/health/delete/{veriID}:
 *   delete:
 *     summary: Sağlık verisini sil
 *     tags: [Health]
 *     parameters:
 *       - in: path
 *         name: veriID
 *         required: true
 *         description: Sağlık verisi ID'si
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Veri silindi
 *       404:
 *         description: Veri bulunamadı
 */
router.delete('/delete/:veriID', verifyToken, healthController.deleteHealthData);

/**
 * @swagger
 * /api/health/son-veri:
 *   get:
 *     summary: Son girilen sağlık verisini getir
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: En son sağlık verisi alındı
 *       404:
 *         description: Veri bulunamadı
 *       500:
 *         description: Sunucu hatası
 */
router.get('/son-veri', verifyToken, healthController.getLastHealthData); // ✅ Eklenen yeni endpoint

/**
 * @swagger
 * /api/health/haftalik:
 *   get:
 *     summary: Son 7 güne ait sağlık verilerini getir
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: Haftalık sağlık verisi alındı
 *       500:
 *         description: Sunucu hatası
 */
router.get('/haftalik', verifyToken, healthController.getWeeklyHealthData);
/**
 * @swagger
 * /api/health/hedef-ozet:
 *   get:
 *     summary: Hedef özet verilerini getir (adım, su, uyku)
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: Özet başarıyla getirildi
 *       500:
 *         description: Sunucu hatası
 */
router.get('/hedef-ozet', verifyToken, healthController.getHedefOzet);
router.get('/bugun', verifyToken, healthController.getTodayHealthData);


module.exports = router;
