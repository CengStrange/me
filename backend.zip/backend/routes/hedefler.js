const express = require('express');
const router = express.Router();
const { poolPromise } = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

// GET: Kullanıcının hedeflerini getir
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input('KullaniciId', req.userId) // 👈 Parametre küçük "d"
      .query('SELECT * FROM Hedefler WHERE KullaniciId = @KullaniciId'); // 👈 Burada da eşleşmeli

    if (result.recordset.length === 0) {
      return res.json({
        adim: 10000,
        uyku: 8,
        su: 2.5
      });
    }

    const hedef = result.recordset[0];
    res.json({
      adim: hedef.AdimHedefi,
      uyku: hedef.UykuHedefi,
      su: hedef.SuHedefi
    });
  } catch (err) {
    console.error('Hedef GET hatası:', err);
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});

// POST: Hedef güncelle veya ekle
router.post('/guncelle', authMiddleware, async (req, res) => {
  const { adim, uyku, su } = req.body;
  const userId = req.userId;

  try {
    const pool = await poolPromise;

    const check = await pool
      .request()
      .input('KullaniciId', userId)
      .query('SELECT * FROM Hedefler WHERE KullaniciId = @KullaniciId');

    if (check.recordset.length > 0) {
      // varsa güncelle
      await pool
        .request()
        .input('AdimHedefi', adim)
        .input('UykuHedefi', uyku)
        .input('SuHedefi', su)
        .input('KullaniciId', userId)
        .query(`
          UPDATE Hedefler SET 
            AdimHedefi = @AdimHedefi, 
            UykuHedefi = @UykuHedefi, 
            SuHedefi = @SuHedefi 
          WHERE KullaniciId = @KullaniciId
        `);
    } else {
      // yoksa ekle
      await pool
        .request()
        .input('KullaniciId', userId)
        .input('AdimHedefi', adim)
        .input('UykuHedefi', uyku)
        .input('SuHedefi', su)
        .query(`
          INSERT INTO Hedefler (KullaniciId, AdimHedefi, UykuHedefi, SuHedefi)
          VALUES (@KullaniciId, @AdimHedefi, @UykuHedefi, @SuHedefi)
        `);
    }

    res.json({ message: 'Hedefler kaydedildi' });
  } catch (err) {
    console.error('Hedef POST hatası:', err);
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});


module.exports = router;
